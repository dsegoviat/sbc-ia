# SBC IA

Se ha probado con la versión de CLIPS 6.30